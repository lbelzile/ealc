#
# #Exponent measure
# V.dir <- function(u, alpha, rho, B=1000){
#   sum(sapply(1:length(u),
#              function(ind){
#                temp <- exp((lgamma(alpha[-ind]+rho)-lgamma(alpha[-ind])+log(u[-ind])-
#                               (lgamma(alpha[ind]+rho)-lgamma(alpha[ind])+log(u[ind])))/rho)
#                mean(replicate(n=1000, mean(sapply(rgamma(B, shape=alpha[ind]+rho, 1) ,
#                 function(y){exp(sum(pgamma(y*temp, shape=alpha[ind], rate = 1,
#                                            lower.tail=TRUE, log.p=TRUE)))}))))/u[ind]
#                 #exp(-sum(lgamma(alpha[-ind])))
#              }))
#
# }
#
#
#
# V.negdir <- function(u, alpha, rho, B=1000){
#   sum(sapply(1:length(u),
#              function(ind){
#                temp <- exp((lgamma(alpha[ind]-rho)-lgamma(alpha[ind])+log(u[ind])-
#                               (lgamma(alpha[-ind]-rho)-lgamma(alpha[-ind])+log(u[-ind])))/rho)
#                mean(replicate(n=1000, mean(sapply(rgamma(B,shape=alpha[ind]-rho,1) ,
#                 function(y){exp(sum(pgamma(y*temp, shape=alpha[ind], rate = 1, lower.tail=FALSE, log.p=TRUE)))}))))/u[ind]
#                  #exp(-sum(lgamma(alpha[-ind])))
#              }))
# }
#

V.dir2 <- function(x, alpha, rho, B=1000){
  k <- exp(lgamma(alpha+rho)-lgamma(alpha))
  gamma(sum(alpha)+rho)/gamma(sum(alpha))*mean(replicate(
    mean(apply(t(exp(rho*log(mev::rdir(n=B,alpha=alpha,normalize=TRUE))))/(x*k),2,max)),n=100))
}


V.dir_is <- function(x, alpha, rho, B=1000){
  k <- exp(lgamma(alpha+rho)-lgamma(alpha))
  d <- length(alpha)
  samp_num <- table(sample.int(d, size=B*100, TRUE))
  sum(sapply(1:d,  function(i){
    mixt <- rep(0, d); mixt[i] <- rho
    samp <- exp(rho*log(mev::rdir(n=samp_num[i],alpha=alpha+mixt,normalize=TRUE)))
  sum(d*apply(t(samp)/(x*k),2,max)/colSums(t(samp)/k))
  }))/(100*B)
}

V.negdir2 <- function(x, alpha, rho, B=1000){
  k <- exp(lgamma(alpha-rho)-lgamma(alpha))
  gamma(sum(alpha)-rho)/gamma(sum(alpha))*mean(replicate(
    mean(apply(t(exp(-rho*log(mev::rdir(n=B,alpha=alpha,normalize=TRUE))))/(x*k),2,max)),n=100))
}

V_sDir_fun <- function(y, alpha, rho){
  if(length(y)!=length(alpha)){
    stop("Invalid argument for `y`; non conformal size") #does not handle matrices
  }
  if(length(y)==2){
      c <- lgamma(alpha+rho)-lgamma(alpha)
      kappa <- exp((log(y[2])+c[2])/rho - log(exp((log(y[2])+c[2])/rho)+exp((log(y[1])+c[1])/rho)))
      return(exp(-log(y[1])+ pbeta(kappa, alpha[2], alpha[1]+rho,log.p=TRUE))+
        exp(-log(y[2])+ pbeta(1-kappa, alpha[1], alpha[2]+rho,log.p=TRUE))
      )
  } else if(length(y)>2){
    require(SimplicialCubature)
  V_sDir_num <- function(x, y, alpha, rho){
    xv <- c(x, 1-sum(x))
    max(exp(rho*log(xv)-log(y)+lgamma(alpha)-lgamma(alpha+rho)))*
      exp(sum((alpha-1)*log(xv)))
  }
  integ <- adaptIntegrateSimplex(f = V_sDir_num, S = CanonicalSimplex(length(alpha)-1),
                        y = y, alpha = alpha, rho = rho,
                        absError = 1e-8, maxEvals=1e10)
  if(integ$returnCode==0){
    return(exp(log(integ$integral)+lgamma(sum(alpha)+rho)-sum(lgamma(alpha))))
  } else{
    return(NA)
  }
  }
}
